import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const ForgetPassword = () => {
  return (
    <View>
      <Text>ForgetPassword</Text>
    </View>
  );
};

export default ForgetPassword;

const styles = StyleSheet.create({});
