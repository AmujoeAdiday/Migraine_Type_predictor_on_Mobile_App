import {useState, useRef, useEffect} from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  Image,
  Alert,
  TouchableOpacity,
  Dimensions,
  Platform,
} from 'react-native';
import RNFetchBlob from 'rn-fetch-blob';
import firestore from '@react-native-firebase/firestore';
import {showMessage, hideMessage} from 'react-native-flash-message';
import auth from '@react-native-firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DropDownPicker from 'react-native-dropdown-picker';
import COLORS from '../conts/colors';
import Input from '../components/Input';
import AnimatedLoader from '../components/AnimatedLoader';
import axios from 'axios';

console.disableYellowBox = true;
const Home = ({navigation, route}) => {
  const [Data, setData] = useState([]);
  const [warning, setWarning] = useState(false);
  const [waiting, setWaiting] = useState(false);
  const [age, setAge] = useState();
  const [duration, setDuration] = useState();
  const [frequency, setFrequency] = useState();
  const [location, setLocation] = useState();
  const [character, setCharacter] = useState();
  const [intensity, setIntensity] = useState();
  const [nausea, setNausea] = useState();
  const [vomit, setVomit] = useState();
  const [phonophobia, setPhonophobia] = useState();
  const [photophobia, setPhotophobia] = useState();
  const [visual, setVisual] = useState();
  const [sensory, setSensory] = useState();
  const [dysphasia, setDysphasia] = useState();
  const [verigo, setVerigo] = useState();
  const [tinnitus, setTinnitus] = useState();
  const [hypoacusis, setHypoacusis] = useState();
  const [defect, setDefect] = useState();
  const [conscience, setConscience] = useState();

  // Open States for DropDownPicker
  const [openDuration, setOpenDurationn] = useState(false);
  const [openFrequency, setOpenFrequency] = useState(false);
  const [openLocation, setOpenLocation] = useState(false);
  const [openCharacter, setOpenCharacter] = useState(false);
  const [openIntensity, setOpenIntensity] = useState(false);
  const [openNausea, setOpenNausea] = useState(false);
  const [openVomit, setOpenVomit] = useState(false);
  const [openPhonophobia, setOpenPhonophobia] = useState(false);
  const [openPhotophobia, setOpenPhotophobia] = useState(false);
  const [openVisual, setOpenVisual] = useState(false);
  const [openSensory, setOpenSensory] = useState(false);
  const [openDysphasia, setOpenDysphasia] = useState(false);
  const [openVerigo, setOpenVerigo] = useState(false);
  const [openTinnitus, setOpenTinnitus] = useState(false);
  const [openHypoacusis, setOpenHypoacusis] = useState(false);
  const [openDefect, setOpenDefect] = useState(false);
  const [openConscience, setOpenConscience] = useState(false);
  const [csvExport, setCsvExport] = useState(false);
  const [userEmail, setUserEmail] = useState();

  const scrollViewRef = useRef();

  const makeApiCall = () => {
    if (
      age === undefined ||
      age === '' ||
      duration === undefined ||
      duration === '' ||
      frequency === undefined ||
      frequency === '' ||
      location === undefined ||
      location === '' ||
      character === undefined ||
      character === '' ||
      intensity === undefined ||
      intensity === '' ||
      nausea === undefined ||
      nausea === '' ||
      vomit === undefined ||
      vomit === '' ||
      phonophobia === undefined ||
      phonophobia === '' ||
      photophobia === undefined ||
      photophobia === '' ||
      visual === undefined ||
      visual === '' ||
      sensory === undefined ||
      sensory === '' ||
      dysphasia === undefined ||
      dysphasia === '' ||
      verigo === undefined ||
      verigo === '' ||
      tinnitus === undefined ||
      tinnitus === '' ||
      hypoacusis === undefined ||
      hypoacusis === '' ||
      defect === undefined ||
      defect === '' ||
      conscience === undefined ||
      conscience === ''
    ) {
      setWarning(true);
      setTimeout(() => {
        setWarning(false);
      }, 2000);
    } else {
      setWaiting(true);
      const baseUrl = 'http://13.112.170.19/';
      const data = JSON.stringify({
        input_1: parseInt(age),
        input_2: duration,
        input_3: frequency,
        input_4: location,
        input_5: character,
        input_6: intensity,
        input_7: nausea,
        input_8: vomit,
        input_9: phonophobia,
        input_10: photophobia,
        input_11: visual,
        input_12: sensory,
        input_13: dysphasia,
        input_14: tinnitus,
        input_15: tinnitus,
        input_16: hypoacusis,
        input_17: defect,
        input_18: conscience,
      });

      const dataToBeSaved = {
        input_1: parseInt(age),
        input_2: duration,
        input_3: frequency,
        input_4: location,
        input_5: character,
        input_6: intensity,
        input_7: nausea,
        input_8: vomit,
        input_9: phonophobia,
        input_10: photophobia,
        input_11: visual,
        input_12: sensory,
        input_13: dysphasia,
        input_14: tinnitus,
        input_15: tinnitus,
        input_16: hypoacusis,
        input_17: defect,
        input_18: conscience,
      };

      var config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: `${baseUrl}`,
        headers: {
          'Content-Type': 'application/json',
        },
        data: data,
      };

      axios(config)
        .then(function (response) {
          console.log(JSON.stringify(response.data));
          setWaiting(false);
          setAge('');
          setCharacter('');
          setConscience('');
          setDefect('');
          setDuration('');
          setDysphasia('');
          setFrequency('');
          setHypoacusis('');
          setIntensity('');
          setLocation('');
          setNausea('');
          setPhonophobia('');
          setPhotophobia('');
          setSensory('');
          setTinnitus('');
          setVerigo('');
          setVisual('');
          setVomit('');
          saveData(dataToBeSaved, response.data);
        })
        .catch(function (error) {
          console.log('Hiiii' + error);
        });
    }
  };

  const logout = () => {
    console.log('before logout');
    try {
      AsyncStorage.setItem('email', '');
      AsyncStorage.setItem('isLogin', 'false');
      navigation.navigate('Login');
      navigation.isWaiting(false);
    } catch (error) {
      console.error(error);
    }
  };

  const autoScroll = () => {
    let offset = 0;
    setInterval(() => {
      offset += 50;
      scrollViewRef.current?.scrollTo({x: 0, y: offset, animated: true});
    }, 500);
  };

  const saveData = (data, predictionData) => {
    data.prediction = predictionData.prediction;
    const prediction = predictionData.prediction;
    console.log(data);
    firestore()
      .collection('predictions')
      .add(data)
      .then(() => {
        navigation.navigate('Prediction', data);
      });
  };

  let durationItems = [
    {label: '1', value: 1},
    {label: '2', value: 2},
    {label: '3', value: 3},
  ];
  let frequencyItem = [
    {label: '1', value: 1},
    {label: '2', value: 2},
    {label: '3', value: 3},
    {label: '4', value: 4},
    {label: '5', value: 5},
    {label: '6', value: 6},
    {label: '7', value: 7},
    {label: '8', value: 8},
  ];
  let locationItem = [
    {label: 'None', value: 0},
    {label: 'Unilateral', value: 1},
    {label: 'Bilateral', value: 2},
  ];
  let characterItem = [
    {label: 'None', value: 0},
    {label: 'Throbbing', value: 1},
    {label: 'Constant', value: 2},
  ];
  let intensityItem = [
    {label: 'None', value: 0},
    {label: 'Mild', value: 1},
    {label: 'Medium', value: 2},
    {label: 'Severe', value: 3},
  ];
  let nauseaItem = [
    {label: 'Not', value: 0},
    {label: 'Yes', value: 1},
  ];
  let vomitItem = [
    {label: 'Not', value: 0},
    {label: 'Yes', value: 1},
  ];
  let phonophobiaItem = [
    {label: 'Not', value: 0},
    {label: 'Yes', value: 1},
  ];
  let photophobiaItem = [
    {label: 'Not', value: 0},
    {label: 'Yes', value: 1},
  ];

  let visualItem = [
    {label: '0', value: 0},
    {label: '1', value: 1},
    {label: '2', value: 2},
    {label: '3', value: 3},
    {label: '4', value: 4},
  ];

  let sensoryItem = [
    {label: '0', value: 0},
    {label: '1', value: 1},
    {label: '2', value: 2},
  ];
  let dysphasiaItem = [
    {label: 'Not', value: 0},
    {label: 'Yes', value: 1},
  ];
  let vertigoItem = [
    {label: 'Not', value: 0},
    {label: 'Yes', value: 1},
  ];
  let tinnitusItem = [
    {label: 'Not', value: 0},
    {label: 'Yes', value: 1},
  ];
  let hypoacusisItem = [
    {label: 'Not', value: 0},
    {label: 'Yes', value: 1},
  ];
  let defectItem = [
    {label: 'Not', value: 0},
    {label: 'Yes', value: 1},
  ];
  let conscienceItem = [
    {label: 'Not', value: 0},
    {label: 'Yes', value: 1},
  ];

  const exportCSV = () => {
    const headerString =
      'input_1,input_2,input_3,input_4,input_5,input_6,input_7,input_8,input_9,input_10,input_11,input_12,input_13,input_14,input_15,input_16,input_17,input_18,prediction\n';

    const rowString = Data.map(
      row =>
        `${row.input_1},${row.input_2},${row.input_3},${row.input_4},${row.input_5},${row.input_6},${row.input_7},${row.input_8},${row.input_9},${row.input_10},${row.input_11},${row.input_12},${row.input_13},${row.input_14},${row.input_15},${row.input_16},${row.input_17},${row.input_18},${row.prediction}\n`,
    ).join('');
    const csvString = `${headerString}${rowString}`;
    const pathToWrite = `${RNFetchBlob.fs.dirs.DownloadDir}/migraine-predictor-dataset.csv`;
    RNFetchBlob.fs
      .writeFile(pathToWrite, csvString, 'utf8')
      .then(() => {
        Alert.alert(
          'Success',
          'File Successfully Expoerted to your downloads Folder',
          [
            {
              text: 'Open File',
              onPress: () => {
                if (Platform.OS === 'ios') {
                  RNFetchBlob.ios.openDocument(pathToWrite);
                } else {
                  RNFetchBlob.android.actionViewIntent(pathToWrite);
                }
              },
            },
            {text: 'OK'},
          ],
        );
      })
      .catch(() => Alert.alert('Something Went Wrong!ß'));
  };
  const getUserEmail = async () => {
    await AsyncStorage.getItem('email').then(value => {
      setUserEmail(value);
      console.log(value);
    });
  };
  useEffect(() => {
    // eslint-disable-next-line react-hooks/exhaustive-deps
    getUserEmail();

    setData([]);
    firestore()
      .collection('predictions')
      .get()
      .then(async response => {
        response.forEach(doc => {
          setData(prev => [
            ...prev,
            {
              input_1: doc.data().input_1,
              input_2: doc.data().input_2,
              input_3: doc.data().input_3,
              input_4: doc.data().input_4,
              input_5: doc.data().input_5,
              input_6: doc.data().input_6,
              input_7: doc.data().input_7,
              input_8: doc.data().input_8,
              input_9: doc.data().input_9,
              input_10: doc.data().input_10,
              input_11: doc.data().input_11,
              input_12: doc.data().input_12,
              input_13: doc.data().input_13,
              input_14: doc.data().input_14,
              input_15: doc.data().input_15,
              input_16: doc.data().input_16,
              input_17: doc.data().input_17,
              input_18: doc.data().input_18,
              prediction: doc.data().prediction,
            },
          ]);
        });
      });

    if (userEmail === 'admin@migrainepredictor.com') {
      // eslint-disable-next-line react-hooks/exhaustive-deps
      setCsvExport(true);
    } else {
      setCsvExport(false);
    }
  }, []);
  return (
    <ScrollView style={{backgroundColor: '#fff', flex: 1}}>
      {!waiting && (
        <View style={styles.InputSection}>
          <View style={{flexDirection: 'row'}}>
            <Text style={styles.title}>Migraine Predictor</Text>
            <TouchableOpacity
              onPress={() => {
                logout();
              }}
              style={{
                width: 62,
                height: 25,
                marginTop: 28,
                marginLeft: 16,
                borderRadius: 5,
                backgroundColor: '#2FB7EC',
                alignItems: 'center',
                justifyContent: 'center',
              }}>
              <View>
                <Text style={{color: 'white'}}>Logout</Text>
              </View>
            </TouchableOpacity>
          </View>

          <Input
            onChangeText={text => setAge(text)}
            keyboard="numeric"
            iconName="user"
            label="Age"
            style={{
              color: 'black',
              width: '100%',
              fontFamily: 'Montserrat-Regular',
            }}
            placeholder="Write your age"
            value={age}
          />

          {/* <View style={{zIndex: 25}}>
            <Text
              style={{
                textAlign: 'left',
                alignSelf: 'flex-start',
                marginTop: -12,
              }}>
              Duration
            </Text>

            <DropDownPicker
              open={openDuration}
              value={duration}
              items={durationItems}
              setOpen={setOpenDurationn}
              setValue={setDuration}
              style={styles.dropdownNew}
              placeholder={'Select Duration'}
              placeholderStyle={{
                color: 'grey',
                fontFamily: 'Montserrat-Regular',
              }}
              textStyle={{
                fontFamily: 'Montserrat-Regular',
              }}
              maxHeight={150}
            />
          </View> */}

          <Input
            onChangeText={text => setDuration(text)}
            keyboard="numeric"
            iconName="user"
            label="Duration"
            style={{
              color: 'black',
              width: '100%',
              fontFamily: 'Montserrat-Regular',
            }}
            placeholder="duration of symptoms in last episode in days"
            value={duration}
          />

          {/* <View style={{zIndex: 24}}>
            <Text
              style={{
                textAlign: 'left',
                alignSelf: 'flex-start',
                marginTop: 4,
              }}>
              Frequency
            </Text>

            <DropDownPicker
              open={openFrequency}
              value={frequency}
              items={frequencyItem}
              setOpen={setOpenFrequency}
              setValue={item => {
                setFrequency(item);
                autoScroll();
              }}
              style={styles.dropdown}
              placeholder={'Select Frequency'}
              placeholderStyle={{
                color: 'grey',
                fontFamily: 'Montserrat-Regular',
              }}
              textStyle={{
                fontFamily: 'Montserrat-Regular',
              }}
              maxHeight={150}
            />
          </View> */}

          <Input
            onChangeText={text => setFrequency(text)}
            keyboard="numeric"
            iconName="user"
            label="Frequency"
            style={{
              color: 'black',
              width: '100%',
              fontFamily: 'Montserrat-Regular',
            }}
            placeholder="frequency of episodes per month"
            value={frequency}
          />

          <View style={{zIndex: 23}}>
            <Text
              style={{
                textAlign: 'left',
                alignSelf: 'flex-start',
                marginTop: 4,
              }}>
              Location
            </Text>

            <DropDownPicker
              open={openLocation}
              value={location}
              items={locationItem}
              setOpen={setOpenLocation}
              setValue={setLocation}
              style={styles.dropdown}
              placeholder={'Select Location'}
              placeholderStyle={{
                color: 'grey',
                fontFamily: 'Montserrat-Regular',
              }}
              textStyle={{
                fontFamily: 'Montserrat-Regular',
              }}
              maxHeight={150}
            />
          </View>

          <View style={{zIndex: 22}}>
            <Text
              style={{
                textAlign: 'left',
                alignSelf: 'flex-start',
                marginTop: 4,
              }}>
              Character
            </Text>

            <DropDownPicker
              open={openCharacter}
              value={character}
              items={characterItem}
              setOpen={setOpenCharacter}
              setValue={setCharacter}
              style={styles.dropdown}
              placeholder={'Select Character'}
              placeholderStyle={{
                color: 'grey',
                fontFamily: 'Montserrat-Regular',
              }}
              textStyle={{
                fontFamily: 'Montserrat-Regular',
              }}
              maxHeight={150}
            />
          </View>

          <View style={{zIndex: 21}}>
            <Text
              style={{
                textAlign: 'left',
                alignSelf: 'flex-start',
                marginTop: 4,
              }}>
              Intensity
            </Text>

            <DropDownPicker
              open={openIntensity}
              value={intensity}
              items={intensityItem}
              setOpen={setOpenIntensity}
              setValue={setIntensity}
              style={styles.dropdown}
              placeholder={'Select Intensity'}
              placeholderStyle={{
                color: 'grey',
                fontFamily: 'Montserrat-Regular',
              }}
              textStyle={{
                fontFamily: 'Montserrat-Regular',
              }}
              maxHeight={150}
            />
          </View>

          <View style={{zIndex: 20}}>
            <Text
              style={{
                textAlign: 'left',
                alignSelf: 'flex-start',
                marginTop: 4,
              }}>
              Nausea
            </Text>

            <DropDownPicker
              open={openNausea}
              value={nausea}
              items={nauseaItem}
              setOpen={setOpenNausea}
              setValue={item => {
                setNausea(item);
                autoScroll();
              }}
              style={styles.dropdown}
              placeholder={'Select Nausea'}
              placeholderStyle={{
                color: 'grey',
                fontFamily: 'Montserrat-Regular',
              }}
              textStyle={{
                fontFamily: 'Montserrat-Regular',
              }}
              maxHeight={150}
            />
          </View>

          <View style={{zIndex: 19}}>
            <Text
              style={{
                textAlign: 'left',
                alignSelf: 'flex-start',
                marginTop: 4,
              }}>
              Vomit
            </Text>

            <DropDownPicker
              open={openVomit}
              value={vomit}
              items={vomitItem}
              setOpen={setOpenVomit}
              setValue={setVomit}
              style={styles.dropdown}
              placeholder={'Select Vomit'}
              placeholderStyle={{
                color: 'grey',
                fontFamily: 'Montserrat-Regular',
              }}
              textStyle={{
                fontFamily: 'Montserrat-Regular',
              }}
              maxHeight={150}
            />
          </View>

          <View style={{zIndex: 18}}>
            <Text
              style={{
                textAlign: 'left',
                alignSelf: 'flex-start',
                marginTop: 4,
              }}>
              Phonophobia
            </Text>

            <DropDownPicker
              open={openPhonophobia}
              value={phonophobia}
              items={phonophobiaItem}
              setOpen={setOpenPhonophobia}
              setValue={setPhonophobia}
              style={styles.dropdown}
              placeholder={'Select Phonophobia'}
              placeholderStyle={{
                color: 'grey',
                fontFamily: 'Montserrat-Regular',
              }}
              textStyle={{
                fontFamily: 'Montserrat-Regular',
              }}
              maxHeight={150}
            />
          </View>

          <View style={{zIndex: 17}}>
            <Text
              style={{
                textAlign: 'left',
                alignSelf: 'flex-start',
                marginTop: 4,
              }}>
              Photophobia
            </Text>

            <DropDownPicker
              open={openPhotophobia}
              value={photophobia}
              items={photophobiaItem}
              setOpen={setOpenPhotophobia}
              setValue={setPhotophobia}
              style={styles.dropdown}
              placeholder={'Select Photophobia'}
              placeholderStyle={{
                color: 'grey',
                fontFamily: 'Montserrat-Regular',
              }}
              textStyle={{
                fontFamily: 'Montserrat-Regular',
              }}
              maxHeight={150}
            />
          </View>

          {/* <View style={{zIndex: 16}}>
            <Text
              style={{
                textAlign: 'left',
                alignSelf: 'flex-start',
                marginTop: 4,
              }}>
              Visual
            </Text>

            <DropDownPicker
              open={openVisual}
              value={visual}
              items={visualItem}
              setOpen={setOpenVisual}
              setValue={setVisual}
              style={styles.dropdown}
              placeholder={'Select Visual'}
              placeholderStyle={{
                color: 'grey',
                fontFamily: 'Montserrat-Regular',
              }}
              textStyle={{
                fontFamily: 'Montserrat-Regular',
              }}
              maxHeight={150}
            />
          </View> */}

          <Input
            onChangeText={text => setVisual(text)}
            keyboard="numeric"
            iconName="user"
            label="Visual"
            style={{
              color: 'black',
              width: '100%',
              fontFamily: 'Montserrat-Regular',
            }}
            placeholder="the number of reversible visual symptoms"
            value={visual}
          />

          {/* <View style={{zIndex: 15}}>
            <Text
              style={{
                textAlign: 'left',
                alignSelf: 'flex-start',
                marginTop: 4,
              }}>
              Sensory
            </Text>

            <DropDownPicker
              open={openSensory}
              value={sensory}
              items={sensoryItem}
              setOpen={setOpenSensory}
              setValue={setSensory}
              style={styles.dropdown}
              placeholder={'Select Sensory'}
              placeholderStyle={{
                color: 'grey',
                fontFamily: 'Montserrat-Regular',
              }}
              textStyle={{
                fontFamily: 'Montserrat-Regular',
              }}
              maxHeight={150}
            />
          </View> */}

          <Input
            onChangeText={text => setSensory(text)}
            keyboard="numeric"
            iconName="user"
            label="Sensory"
            style={{
              color: 'black',
              width: '100%',
              fontFamily: 'Montserrat-Regular',
            }}
            placeholder="the number of reversible sensory symptoms"
            value={sensory}
          />

          <View style={{zIndex: 14}}>
            <Text
              style={{
                textAlign: 'left',
                alignSelf: 'flex-start',
                marginTop: 4,
              }}>
              Dysphasia
            </Text>

            <DropDownPicker
              open={openDysphasia}
              value={dysphasia}
              items={dysphasiaItem}
              setOpen={setOpenDysphasia}
              setValue={setDysphasia}
              style={styles.dropdown}
              placeholder={'Select Dysphasia'}
              placeholderStyle={{
                color: 'grey',
                fontFamily: 'Montserrat-Regular',
              }}
              textStyle={{
                fontFamily: 'Montserrat-Regular',
              }}
              maxHeight={150}
            />
          </View>

          <View style={{zIndex: 13}}>
            <Text
              style={{
                textAlign: 'left',
                alignSelf: 'flex-start',
                marginTop: 4,
              }}>
              Vertigo
            </Text>

            <DropDownPicker
              open={openVerigo}
              value={verigo}
              items={vertigoItem}
              setOpen={setOpenVerigo}
              setValue={setVerigo}
              style={styles.dropdown}
              placeholder={'Select Verigo'}
              placeholderStyle={{
                color: 'grey',
                fontFamily: 'Montserrat-Regular',
              }}
              textStyle={{
                fontFamily: 'Montserrat-Regular',
              }}
              maxHeight={150}
            />
          </View>

          <View style={{zIndex: 12}}>
            <Text
              style={{
                textAlign: 'left',
                alignSelf: 'flex-start',
                marginTop: 4,
              }}>
              Tinnitus
            </Text>

            <DropDownPicker
              open={openTinnitus}
              value={tinnitus}
              items={tinnitusItem}
              setOpen={setOpenTinnitus}
              setValue={setTinnitus}
              style={styles.dropdown}
              placeholder={'Select Tinnitus'}
              placeholderStyle={{
                color: 'grey',
                fontFamily: 'Montserrat-Regular',
              }}
              textStyle={{
                fontFamily: 'Montserrat-Regular',
              }}
              maxHeight={150}
            />
          </View>

          <View style={{zIndex: 11}}>
            <Text
              style={{
                textAlign: 'left',
                alignSelf: 'flex-start',
                marginTop: 4,
              }}>
              Hypoacusis
            </Text>

            <DropDownPicker
              open={openHypoacusis}
              value={hypoacusis}
              items={hypoacusisItem}
              setOpen={setOpenHypoacusis}
              setValue={setHypoacusis}
              style={styles.dropdown}
              placeholder={'Select Hypoacusis'}
              placeholderStyle={{
                color: 'grey',
                fontFamily: 'Montserrat-Regular',
              }}
              textStyle={{
                fontFamily: 'Montserrat-Regular',
              }}
              maxHeight={150}
            />
          </View>

          <View style={{zIndex: 10}}>
            <Text
              style={{
                textAlign: 'left',
                alignSelf: 'flex-start',
                marginTop: 4,
              }}>
              Defect
            </Text>

            <DropDownPicker
              open={openDefect}
              value={defect}
              items={defectItem}
              setOpen={setOpenDefect}
              setValue={setDefect}
              style={styles.dropdown}
              placeholder={'Select Defect'}
              placeholderStyle={{
                color: 'grey',
                fontFamily: 'Montserrat-Regular',
              }}
              textStyle={{
                fontFamily: 'Montserrat-Regular',
              }}
              maxHeight={150}
            />
          </View>

          <View style={{zIndex: 9, paddingBottom: 48}}>
            <Text
              style={{
                textAlign: 'left',
                alignSelf: 'flex-start',
                marginTop: 4,
              }}>
              Conscience
            </Text>

            <DropDownPicker
              open={openConscience}
              value={conscience}
              items={conscienceItem}
              setOpen={setOpenConscience}
              setValue={setConscience}
              style={styles.dropdown}
              placeholder={'Select Conscience'}
              placeholderStyle={{
                color: 'grey',
                fontFamily: 'Montserrat-Regular',
              }}
              textStyle={{
                fontFamily: 'Montserrat-Regular',
              }}
              maxHeight={150}
            />
          </View>

          {warning && (
            <Text style={{color: 'red'}}>Please fill all available fields</Text>
          )}
          <TouchableOpacity
            onPress={() => {
              makeApiCall();
            }}
            style={styles.appButtonContainer}>
            <Text style={styles.appButtonText}>{'Predict'}</Text>
          </TouchableOpacity>
          {true && (
            <TouchableOpacity
              onPress={() => {
                exportCSV();
              }}
              style={styles.appButtonCSV}>
              <Text style={styles.appButtonText}>{'Export Data'}</Text>
            </TouchableOpacity>
          )}
        </View>
      )}
      {waiting && (
        <View
          style={{
            height: Dimensions.get('window').height,
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <AnimatedLoader visible={true} />
        </View>
      )}
    </ScrollView>
  );
};

export default Home;

const styles = StyleSheet.create({
  MainView: {
    flex: 1,
    backgroundColor: '#2FB7EC',
    paddingTop: 20,
  },
  image: {
    width: 300,
    height: 180,
    marginBottom: 20,
    marginTop: 50,
    resizeMode: 'contain',
  },
  Pressable: {
    width: '100%',
    height: 60,
    borderRadius: 10,
    color: '#ffff',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#2FB7EC',
    marginTop: 30,
  },
  InputSection: {
    padding: 16,
    paddingTop: 30,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },
  TopText: {
    flex: 0.6,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },
  title: {
    marginTop: 25,
    marginBottom: 25,
    color: '#000',
    fontFamily: 'Montserrat-Black',
    fontSize: 24,
  },
  tagline: {
    color: '#000',
    fontFamily: 'Montserrat-Medium',
    marginBottom: 10,
  },
  text: {
    textAlign: 'center',
    marginTop: 10,
    fontFamily: 'Montserrat-Regular',
    color: 'red',
    position: 'absolute',
    left: 20,
    top: 220,
  },
  appButtonContainer: {
    zIndex: 8,
    margin: 8,
    elevation: 8,
    backgroundColor: '#2FB7EC',
    borderRadius: 5,
    paddingVertical: 10,
    paddingHorizontal: 12,
    width: '100%',
    height: 50,
    marginTop: 30,
    justifyContent: 'center',
  },
  appButtonCSV: {
    zIndex: 8,
    margin: 8,
    elevation: 8,
    backgroundColor: '#2FB7EC',
    borderRadius: 5,
    paddingVertical: 10,
    paddingHorizontal: 12,
    width: '100%',
    height: 50,
    justifyContent: 'center',
  },
  appButtonText: {
    fontSize: 18,
    color: '#fff',
    fontFamily: 'Montserrat-ExtraBold',
    alignSelf: 'center',
    textTransform: 'uppercase',
  },
  dropdown: {
    borderColor: COLORS.darkBlue,
    borderRadius: 4,
    height: 60,
    color: 'red',
    marginTop: 4,
  },
  dropdownNew: {
    borderColor: COLORS.darkBlue,
    borderRadius: 4,
    height: 60,
    color: 'red',
    marginTop: 4,
  },
});
