import {useEffect, useState} from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  Image,
  Alert,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import auth from '@react-native-firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Input from '../components/Input';
import AnimatedLoader from '../components/AnimatedLoader';
console.disableYellowBox = true;
export const LoginPage = ({navigation}) => {
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const [waiting, setWaiting] = useState(false);

  const storeUser = async () => {
    console.log('inside store user');
    try {
      await AsyncStorage.setItem('email', email.trim().toLowerCase());
      await AsyncStorage.setItem('isLogin', 'true');
      console.log('stored user');
    } catch (error) {
      console.log('loggin error');
      console.error(error);
    }
  };
  const LoginButtonPressed = () => {
    setWaiting(true);
    console.log(waiting);
    auth()
      .signInWithEmailAndPassword(email.trim().toLowerCase(), password)
      .then(() => {
        storeUser();
        navigation.navigate('Home', {userEmail: email.trim().toLowerCase()});
        navigation.setWaiting(false);
        // const get = await AsyncStorage.getItem('isLogin');
      })
      .catch(error => {
        console.log('catching error');
        console.error(error);
        if (error.code === 'auth/network-request-failed') {
          setWaiting(false);
          Alert.alert('Please check your Internet Connection!');
        } else {
          setWaiting(false);
          // Alert.alert('InValid Email Address or Password!');
        }
      });
  };

  return (
    <ScrollView style={{backgroundColor: '#fff', flex: 1}}>
      {!waiting && (
        <ScrollView style={styles.MainView}>
          <View style={styles.TopText}>
            <Text style={styles.title}>Migraine Predictor</Text>
            <Text style={styles.tagline}>
              Please Log In to your Account to Continue!
            </Text>
          </View>
          <View style={styles.InputSection}>
            <Input
              onChangeText={text => setEmail(text)}
              iconName="user"
              label="Email Address"
              style={{
                color: 'black',
                width: '100%',
                fontFamily: 'Montserrat-Regular',
              }}
              placeholder="Enter your Email Address"
              value={email}
            />
            <Input
              onChangeText={text => setPassword(text)}
              iconName="lock"
              label="Password"
              style={{
                color: 'black',
                width: '100%',
                fontFamily: 'Montserrat-Regular',
              }}
              placeholder="Enter Your Password"
              value={password}
              secureTextEntry={true}
            />
            <Text
              style={styles.text}
              onPress={() => {
                navigation.navigate('ForgotPassword');
              }}>
              Forgot Password?
            </Text>

            <TouchableOpacity
              onPress={() => {
                LoginButtonPressed();
              }}
              style={styles.appButtonContainer}>
              <Text style={styles.appButtonText}>{'Login Now!'}</Text>
            </TouchableOpacity>
            <Text
              style={{
                marginTop: 50,
                fontSize: 12,
                color: 'black',
                fontFamily: 'Montserrat-Regular',
              }}>
              Don't Have an Account?
            </Text>
            <Text
              style={{
                marginTop: 10,
                fontSize: 18,
                textDecorationLine: 'underline',
                color: 'black',
                fontFamily: 'Montserrat-ExtraBold',
              }}
              onPress={() => navigation.navigate('Register')}>
              Register Now!
            </Text>
          </View>
        </ScrollView>
      )}
      {waiting && (
        <View
          style={{
            height: Dimensions.get('window').height,
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <AnimatedLoader visible={true} />
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  MainView: {
    flex: 1,
    backgroundColor: '#2FB7EC',
    paddingTop: 20,
  },
  image: {
    width: 300,
    height: 180,
    marginBottom: 20,
    marginTop: 50,
    resizeMode: 'contain',
  },
  Pressable: {
    width: '100%',
    height: 60,
    borderRadius: 10,
    color: '#ffff',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#2FB7EC',
    marginTop: 30,
  },
  InputSection: {
    padding: 16,
    paddingTop: 30,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
    borderTopRightRadius: 20,
    borderTopLeftRadius: 20,
  },
  TopText: {
    flex: 0.6,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },
  title: {
    marginTop: 75,
    marginBottom: 25,
    color: '#000',
    fontFamily: 'Montserrat-Black',
    fontSize: 24,
  },
  tagline: {
    color: '#000',
    fontFamily: 'Montserrat-Medium',
    marginBottom: 10,
  },
  text: {
    textAlign: 'center',
    marginTop: 10,
    fontFamily: 'Montserrat-Regular',
    color: 'red',
    position: 'absolute',
    left: 20,
    top: 220,
  },
  appButtonContainer: {
    margin: 8,
    elevation: 8,
    backgroundColor: '#2FB7EC',
    borderRadius: 5,
    paddingVertical: 10,
    paddingHorizontal: 12,
    width: '100%',
    height: 50,
    marginTop: 30,
    justifyContent: 'center',
  },
  appButtonText: {
    fontSize: 18,
    color: '#fff',
    fontFamily: 'Montserrat-ExtraBold',
    alignSelf: 'center',
    textTransform: 'uppercase',
  },
});
