import {StyleSheet, Text, View, TouchableOpacity} from 'react-native';
import React from 'react';
import COLORS from '../conts/colors';

const Prediction = ({route, navigation}) => {
  const {prediction} = route.params;
  return (
    <View style={{flex: 1, alignItems: 'center'}}>
      <Text style={styles.title}>Migraine Predictor</Text>
      <Text
        style={{
          textAlign: 'left',
          alignSelf: 'flex-start',
          marginTop: -12,
          marginLeft: 16,
        }}>
        Prediction
      </Text>
      <View
        style={{
          borderRadius: 10,
          borderWidth: 1,
          width: '90%',
          marginTop: 10,
          alignItems: 'center',
          borderColor: COLORS.darkBlue,
        }}>
        <Text style={styles.subTitle}>{prediction}</Text>
      </View>

      <TouchableOpacity
        onPress={() => {
          navigation.navigate('Home');
        }}
        style={styles.appButtonContainer}>
        <Text style={styles.appButtonText}>{'Go Back'}</Text>
      </TouchableOpacity>
    </View>
  );
};
export default Prediction;

const styles = StyleSheet.create({
  title: {
    marginTop: 50,
    marginBottom: 25,
    color: '#000',
    fontFamily: 'Montserrat-Black',
    fontSize: 24,
  },
  subTitle: {
    marginTop: 16,
    marginBottom: 25,
    color: '#000',
    fontFamily: 'Montserrat-Regular',
    fontSize: 18,
  },
  appButtonContainer: {
    zIndex: 8,
    margin: 8,
    elevation: 8,
    backgroundColor: '#2FB7EC',
    borderRadius: 5,
    paddingVertical: 10,
    paddingHorizontal: 12,
    width: '90%',
    height: 50,
    marginTop: 30,
    justifyContent: 'center',
  },
  appButtonText: {
    fontSize: 18,
    color: '#fff',
    fontFamily: 'Montserrat-ExtraBold',
    alignSelf: 'center',
    textTransform: 'uppercase',
  },
});
