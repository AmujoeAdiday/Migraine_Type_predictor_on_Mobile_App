import {StyleSheet, Text, View} from 'react-native';
import React, {useEffect} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {useNavigation} from '@react-navigation/native';

const SplashScreen = () => {
  const navigation = useNavigation();

  async function nextScreen() {
    let login = await AsyncStorage.getItem('isLogin');
    setTimeout(() => {
      if (login === 'true') {
        console.log('Hi');
        navigation.navigate('Home');
      } else {
        console.log('Hello');
        console.log(login);
        navigation.navigate('Login');
      }
    }, 1000);
  }
  useEffect(() => {
    nextScreen();
  });

  return (
    <View
      style={{
        alignContent: 'center',
        alignItems: 'center',
        justifyContent: 'center',
      }}>
      <Text style={styles.title}>Migraine Predictor</Text>
    </View>
  );
};

export default SplashScreen;

const styles = StyleSheet.create({
  title: {
    marginTop: 350,
    color: '#000',
    fontFamily: 'Montserrat-Black',
    fontSize: 24,
  },
});
