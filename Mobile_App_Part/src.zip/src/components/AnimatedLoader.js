import React from 'react';
import {StyleSheet, View, Text} from 'react-native';
import LottieView from 'lottie-react-native';
import {useState} from 'react';
export default function AnimatedLoader(props) {
  return (
    <View style={{alignSelf: 'center', alignItems: 'center'}}>
      {props.visible && (
        <LottieView
          source={require('./../assets/json/loading.json')}
          style={styles.animation}
          autoPlay
        />
      )}
    </View>
  );
}
const styles = StyleSheet.create({
  animation: {
    width: 100,
    height: 100,
  },
});
