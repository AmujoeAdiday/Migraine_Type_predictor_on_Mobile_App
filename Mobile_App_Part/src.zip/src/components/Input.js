/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {View, Text, TextInput, StyleSheet} from 'react-native';
import COLORS from '../conts/colors';
const Input = ({
  label,
  iconName,
  error,
  password,
  multiline = false,
  lines = 1,
  viewStyle,
  keyboard = 'default',
  onFocus = () => {},
  ...props
}) => {
  const [hidePassword, setHidePassword] = React.useState(password);
  const [isFocused, setIsFocused] = React.useState(false);
  return (
    <View style={[{marginBottom: 20}, {viewStyle}]}>
      <Text style={style.label}>{label}</Text>
      <View
        style={[
          multiline ? style.inputContainerTwo : style.inputContainerOne,
          {
            borderColor: COLORS.darkBlue,
          },
        ]}>
        <TextInput
          autoCorrect={false}
          keyboardType={keyboard}
          onFocus={() => {
            onFocus();
            setIsFocused(true);
          }}
          multiline={multiline}
          numberOfLines={lines}
          onBlur={() => setIsFocused(false)}
          secureTextEntry={hidePassword}
          placeholderTextColor={'#808080'}
          style={{
            color: COLORS.black,
            flex: 1,
            fontFamily: 'Montserrat-Regular',
          }}
          {...props}
        />
      </View>
    </View>
  );
};

const style = StyleSheet.create({
  label: {
    marginVertical: 5,
    fontSize: 14,
    color: COLORS.black,
    fontFamily: 'Montserrat-Regular',
  },
  inputContainerOne: {
    height: 60,
    backgroundColor: 'white',
    flexDirection: 'row',
    paddingHorizontal: 15,
    borderWidth: 1,
    alignItems: 'center',
    borderColor: 'black',
    borderRadius: 5,
  },
  inputContainerTwo: {
    height: 95,
    backgroundColor: COLORS.light,
    flexDirection: 'row',
    paddingHorizontal: 15,
    borderWidth: 1,
    paddingTop: 8,
    borderRadius: 5,
  },
});

export default Input;
